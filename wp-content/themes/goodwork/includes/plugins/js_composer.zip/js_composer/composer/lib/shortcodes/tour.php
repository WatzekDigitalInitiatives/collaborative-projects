<?php
/**
 */

class WPBakeryShortCode_VC_Tour extends  WPBakeryShortCode_VC_Tabs {}